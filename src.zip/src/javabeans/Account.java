package javabeans;

import java.util.Date;

public class Account {
	private String SSN;
	private int cardNum;
	private Date acctCreationDate;
	
	public Account() {}

	public Date getAcctCreationDate() {
		return acctCreationDate;
	}

	public void setAcctCreationDate(Date acctCreationDate) {
		this.acctCreationDate = acctCreationDate;
	}

	public int getCardNum() {
		return cardNum;
	}

	public void setCardNum(int cardNum) {
		this.cardNum = cardNum;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}
	
	
}
