package javabeans;

import java.util.Date;

public class User extends Person{
	private String PPP;
	private int rating;
	private Date dateOfLastAct;
	
	public User() {
		super();
	}
	
	public String getPPP() {
		return PPP;
	}
	public void setPPP(String PPP) {
		this.PPP = PPP;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Date getLastAct() {
		return dateOfLastAct;
	}
	public void setLastAct(Date dateOfLastAct) {
		this.dateOfLastAct = dateOfLastAct;
	}
}
