package sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//import com.mysql.cj.jdbc.Driver;
import javabeans.Person;
import javabeans.Dates;
import javabeans.Login;
import javabeans.User;
import javabeans.salesReport;

public class uersData {
	
	public void insertPerson(Connection connection, Person person) throws SQLException{
		String sql = "insert into hsinlin.Person(SSN,Password,FirstName,LastName,Street,City,State,Zipcode,Email,Telephone)" 
						+ "values(?,?,?,?,?,?,?,?,?,?)";
		
		PreparedStatement ps = (PreparedStatement)connection.prepareStatement(sql);
		
		ps.setString(1, person.getSSN());
		ps.setString(2, person.getpassword());
		ps.setString(3, person.getfirstName());
		ps.setString(4, person.getLastName());
		ps.setString(5, person.getStreet());
		ps.setString(6, person.getCity());
		ps.setString(7, person.getState());
		ps.setInt(8, person.getzip());
		ps.setString(9, person.getemail());
		ps.setString(10, person.gettelephone());	
		ps.executeUpdate();
	}
	
	public ArrayList<Dates> searchPendingDates(Connection connection, String profile, Calendar date) throws SQLException{
		String sql = "Select D.Profile2, D.Location, D.Date_Time, D.BookingFee"
				+ " From hsinlin.Date D "
				+ "Where D.Date_Time >= ? AND D.Profile1 = ?";
		
		PreparedStatement ps = (PreparedStatement) connection.prepareStatement(sql);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date pendingD = date.getTime();

	    System.out.println(dateFormat.format(pendingD));

		ps.setString(1, dateFormat.format(pendingD));
 		ps.setString(2, profile);
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<Dates> pendingDates = new ArrayList<Dates>();
		
		while(rs.next()) {
			   Dates d = new Dates();
			   d.setProfile2(rs.getString("Profile2"));
			   
			   Calendar cal = Calendar.getInstance();
			   cal.setTime(rs.getDate("Date_Time"));
			   d.setDateTime(cal);
			   //System.out.println(rs.getDate("Date_Time"));
			   
			   d.setLocation(rs.getString("Location"));
			   //System.out.println(rs.getString("Profile2"));
			   
			   d.setBookingFee(rs.getDouble("BookingFee"));
			   //System.out.println(rs.getDouble("BookingFee"));
			   
			   pendingDates.add(d);
			   //System.out.println("in while");
			  
		  }
		  return pendingDates;
	}
	
	public static ArrayList<Dates> searchPastDates(Connection connection, String profile, Calendar date) throws SQLException{
		String sql = "Select D.Profile2, D.Location, D.Date_Time"
				+ " From hsinlin.Date D "
				+ "Where D.Date_Time <= ? AND D.Profile1 = ?";
		
		PreparedStatement ps = (PreparedStatement) connection.prepareStatement(sql);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
 		ps.setString(1, profile);
		ps.setString(2, dateFormat.format(date));
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<Dates> pastDates = new ArrayList<Dates>();
		
		while(rs.next()) {
			   Dates d = new Dates();
			   d.setProfile1(rs.getString("Profile1"));
			   System.out.println(rs.getString("Profile1"));

			   d.setProfile2(rs.getString("Profile2"));
			   
			   d.setCustRep(rs.getString("CustRep"));
			   System.out.println(rs.getString("custRep"));
			   
			   Calendar cal = Calendar.getInstance();
			   cal.setTime(rs.getDate("Date_Time"));
			   d.setDateTime(cal);
			   System.out.println(rs.getDate("Date_Time"));
			   
			   d.setLocation(rs.getString("Location"));
			   System.out.println(rs.getString("Location"));
			   
			   d.setBookingFee(rs.getDouble("BookingFee"));
			   //System.out.println(rs.getDouble("BookingFee"));
			   
			   d.setComments(rs.getString("Comments"));
			   //System.out.println(rs.getString("Profile2"));
			   

			   d.setUser1Rating(rs.getInt("User1Rating"));
			   

			   d.setUser2Rating(rs.getInt("User2Rating"));
			   
			   pastDates.add(d);
			   //System.out.println("in while");
			  
		  }
		  return pastDates;
	}

}
